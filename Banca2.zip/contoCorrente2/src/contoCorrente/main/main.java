package contoCorrente.main;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.mifmif.common.regex.Generex;
import contoCorrente.model.Conto;
import contoCorrente.model.ContoCorrente;
import contoCorrente.model.ContoDeposito;
import contoCorrente.model.ContoInvestimento;
import contoCorrente.model.Correntista;
import contoCorrente.model.Movimento;



public class main {
	
	static LocalDate    inizio21=LocalDate.parse("2021-01-01"),
  			 			fine21=LocalDate.parse("2021-12-31"),
  			 			inizio22=LocalDate.parse("2022-01-01"),
  			 			fine22=LocalDate.parse("2022-12-31"),
						inizio23=LocalDate.parse("2023-01-01"),
						fine23=LocalDate.now();
	
	
	public static void main(String[] args) {

		  Correntista cor;
		  Scanner scan= new Scanner(System.in); 

		  System.out.println("Banca");
		  
		  cor=init(scan);
		  
		  
		  
		  Conto contoCorrente=new ContoCorrente(cor);
		  
		  System.out.println(String.format("\n%100s"," ").replace(" " , "-")+"\n\t\t\t   "+contoCorrente.getClass().getSimpleName().replace("Conto","Conto ").toUpperCase()+"\n"+String.format("\n%100s"," ").replace(" " , "-"));

		 
		  annoAttività(inizio21, fine21 ,  scan,contoCorrente);
		  annoAttività(inizio22, fine22 ,  scan,contoCorrente);
		  annoAttività(inizio23, fine23 ,  scan,contoCorrente);
		  
		  

		  Conto contoDeposito=new ContoDeposito(cor);
		 
		  System.out.println(String.format("\n%100s"," ").replace(" " , "-")+"\n\t\t\t   "+contoDeposito.getClass().getSimpleName().replace("Conto","Conto ").toUpperCase()+"\n"+String.format("\n%100s"," ").replace(" " , "-"));

		  
		  annoAttività(inizio21, fine21 ,  scan,contoDeposito);
		  annoAttività(inizio22, fine22 ,  scan,contoDeposito);
		  annoAttività(inizio23, fine23 ,  scan,contoDeposito);
		  
		  
		  
		  Conto contoInvestimento=new ContoInvestimento(cor);
		  
		  System.out.println(String.format("\n%100s"," ").replace(" " , "-")+"\n\t\t\t   "+contoInvestimento.getClass().getSimpleName().replace("Conto","Conto ").toUpperCase()+"\n"+String.format("\n%100s"," ").replace(" " , "-"));

		  
		  annoAttività(inizio21, fine21 ,  scan,contoInvestimento);
		  annoAttività(inizio22, fine22 ,  scan,contoInvestimento);
		  annoAttività(inizio23, fine23 ,  scan,contoInvestimento);
		  
		  scan.close();
		 
		
		
	}
	
	public static void annoAttività(LocalDate inizioAnno, LocalDate fineAnno, Scanner scan,Conto conto) {
		
		Random random = new Random();
		LocalDate tmp=inizioAnno;
		Boolean ins=false;
		
		System.out.println(""+String.format("%100s"," ").replace(" " , "-")+"\n\t\t\t\t"+inizioAnno.getYear()+" \n"+String.format("%100s"," ").replace(" " , "-"));
		  do {
			  ins=operazione(scan,conto,tmp,inizioAnno,fineAnno);
			  tmp=tmp.plusDays(random.nextInt(45-20)+20);
		  }while(ins);
		  
		  conto.writePDF(inizioAnno,fineAnno,""+conto.getClass().getName().replace("contoCorrente.model.Conto","Conto")+"_"+inizioAnno.getYear()+".pdf");
		
		
		
	}
	
	
	public static boolean  operazione(Scanner scan,Conto c,LocalDate tmp,LocalDate dataInizioEstratto,LocalDate dataFineEstratto) {
		
		String ins="e";
		boolean ret=true;
		do {ins= insOp(scan,c,tmp,dataInizioEstratto,dataFineEstratto);} while(ins=="e");
		if(ins=="chiusura") {
			
			ret=false;
		}
		
		return ret;
		
	}
	
	private static String insOp(Scanner scan,Conto c,LocalDate tmp,LocalDate dataInizioEstratto,LocalDate dataFineEstratto) {
		
	
		String r="";
		String input;
		int importo;
		
		

		HashSet<String> enumNames = new HashSet<String>();
		for (Movimento.MOVIMENTI i : Movimento.MOVIMENTI.values()) {
			enumNames.add(i.name());
		}

		try {
			System.out.println(String.format("\n%100s", " ").replace(" ", "-") + "\nOperazioni possibili :\n"
					+ String.format("%33s\n", " ").replace(" ", "-  ") + Movimento.getEnum()
					+ String.format("\n%100s", " ").replace(" ", "-")
					+ "\nInserisci la tipologia di operazione che vuoi effeturare:\n");

			input = scan.next().toUpperCase();

			if (!enumNames.contains(input)) {
				throw new InputMismatchException("!!");
			} else {

				switch (input) {

				case "PRELIEVO": {
					System.out.println("\n<<<<<PRELIEVO");
					importo = insImporto(scan);
					System.out.println("----------------\nPRELIEVO DI " + importo + "\n ----------------");

					c.prelievo(tmp, importo);
					break;
				}
				case "VERSAMENTO": {
					System.out.println("\n>>>>VERSAMENTO");
					importo = insImporto(scan);
					System.out.println("----------------\nVERSAMENTO DI " + importo + "\n ----------------");

					c.versamento(tmp, importo);
					break;

				}

				case "ESTRATTO": {

					c.generaInteressi(dataInizioEstratto, dataFineEstratto);
					c.estrattoConto(dataInizioEstratto, dataFineEstratto);
					
					r = "chiusura";
					break;
				}
				case "CHIUSURA": {

					// LocalDate d=LocalDate.now();
					// c.generaInteressi(LocalDate.parse(""+d.getYear()+"-01-01"));

					c.generaInteressi(dataInizioEstratto, dataFineEstratto);
					c.estrattoConto(dataInizioEstratto, dataFineEstratto);

					r = "chiusura";
					break;
				}
				case "INTERESSI": {
					break;
				}
			}
			}

		} catch (InputMismatchException e) {

			System.out.println(
					"\n-----------------------------------\nErrore:Nome non valido\n-----------------------------------\n\n");
			r = "e";

		}

		
		
		
		return r;
		
	}

	private static  int insImporto(Scanner scan) {
		int ret=0;

		try {
			
			System.out.print("\nInserisci l'importo:\t");
			ret=scan.nextInt();
			

		}catch (InputMismatchException e) {

			System.out.println("\n-----------------------------------\nImporto non valido\n-----------------------------------\n\n");
			ret=0;
		
		}
		return  ret;
		
	}

	public static Correntista init(Scanner scan) {
		String nome="";
		LocalDate d=null;
		Correntista c;
		
		do{nome=insNome(scan);}       	 while(nome=="");
		do{d=insData(scan);}		  	 while(d==null);
		do{c=creaCorrentista(nome, d);}	 while(c==null);
		
		return c;
	}

	private static Correntista creaCorrentista(String nome,LocalDate d) {

		
		Correntista cor=null;
		


		try {

			cor= new Correntista(nome,d);

		} catch (IllegalArgumentException e) {

			System.out.println(e.getMessage()+"\n Immetti nuovamente la Data");
			
		}
		return cor;




	}
	private static String insNome(Scanner scan) {

		String ret=null;
		Pattern pattern =Pattern.compile("[a-zA-Z]{2}[a-zA-Z]*");

		try {
			
			System.out.println("\nInserisci il nome del Correntista");
			ret=scan.nextLine();
			Matcher matcher = pattern.matcher(ret);
			boolean g=matcher.find();
			if(!g) {throw  new InputMismatchException ("!!");}


		}catch (InputMismatchException e) {

			System.out.println("\n-----------------------------------\nErrore:Noem non valido\n-----------------------------------\n\n");
			ret="";
		
		}
		return ret;
	}
	private static String  stringData(Scanner scan) {

		Pattern pattern =Pattern.compile("[12][0-9]{3}-[0123][0-9]-[0123][0-9]");
		String   ret="";



		try {
			System.out.println("\nInserisci la data di nascita(yyyy-mm-dd)");
			ret=scan.nextLine();
			Matcher matcher = pattern.matcher(ret);
			boolean g=matcher.find();
			if(!g) {throw  new InputMismatchException ("!!");}
		}catch (InputMismatchException e) {

			System.out.println("\n-----------------------------------\nErrore: Data inserita nel formato scorretto\n\n-----------------------------------\n\n");
			ret="";
		
		}

		return ret;

	}
	
	private static LocalDate insData(Scanner scan) {
		LocalDate d=null;
	try {
			
		  d=LocalDate.parse(stringData(scan));

		} catch (IllegalArgumentException e) {

			System.out.println(e.getMessage()+"\n Immetti nuovamente la Data");
			
		} catch (DateTimeParseException e) {

			System.out.println("\n Immetti nuovamente la Data");
			
		}
		
		return d;
	}	
	
	public static String genDate(String anno) {
		

		String 	 giorniVenti="([012][0-9])",
				 giorniTrentuno="("+giorniVenti+"|(3[01]))",
				 giorniTrenta="("+giorniVenti+"|(30))",
				 giorniFebbraio="(([01][0-9])|(2[0-8]))",
				 mesiTrentunoSingolaCifra="(0[13578]-("+giorniTrentuno+"))",
				 mesiTrentunoDoppiaCifra="(1[02]-("+giorniTrentuno+"))",
				 mesiTrenta="(((0[469])|11)-("+giorniTrenta+"))",
				 febbraio="(02-"+giorniFebbraio+")";

		
		Generex generex = new Generex( anno+"-("
										+ mesiTrentunoSingolaCifra+"|"
										+ mesiTrentunoDoppiaCifra+"|"
										+ mesiTrenta+"|"
										+febbraio+")");
		
		return generex.random();
		
		
	}
	
	
	
	


}
