package contoCorrente.model;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.Duration;
import java.time.LocalDate;

import java.time.ZoneId;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;



public class ContoCorrente extends Conto {
	
	
	public static double tassoInteresse= 0.07;

//	--COSTR-------------------------------------------------------------------------------------------
	
	public ContoCorrente(Correntista cor) throws IllegalArgumentException {
		super(cor);
		// TODO Auto-generated constructor stub
	}
	
//	--MTD-------------------------------------------------------------------------------------------	
	
	
	@Override
	public double generaInteressi(LocalDate dataInizio, LocalDate dataFine) {

		double tmpSaldo;
		long  giorniSaldoStabile;
		LocalDate tmpDate = dataInizio;
		LocalDate tmp=null;
		double interessi = 0.0,intParziali = 0.0, intGiornaliero = tassoInteresse / 365.0;

//		Serve per limitare le cifre dopo la virgola es: 1.12345 -> 1.12
		NumberFormat nf = NumberFormat.getInstance(new Locale("it", "IT"));
		nf.setMaximumFractionDigits(2);
		nf.setRoundingMode(RoundingMode.UP);
		
		
		logger.warn(String.format("%100s", " ").replace(" ", "-")+"<br />");
		logger.warn(String.format("%100s", " ").replace(" ", "-")+"<br />");
		
//		Mette il nome della classe che genere gli interessi e l'anno dei movimenti 	
		logger.warn("<span style='color: red'><b>"
				+ this.getClass().getSimpleName().replace("Conto","Conto ")
				+ "</b></span>\t\t\tANNO <b>" + dataInizio.getYear() + "</b><br /><br/>");
		
		int i=0;
		for (Entry<LocalDate, LinkedList<Movimento>> entry : movimenti.tailMap(dataInizio).entrySet()) {

			

			/*
			 * Controlla se il giorno del primo movimento è superiore al giorno dell'inizio fattura
			 * Calcola gli interessi prendendo il saldo finale dell'anno precedente
			 * 
			 */
			
			if(i==0) {
				tmp=entry.getKey();
				i++;
				
			}
			if ( tmp.isAfter(dataInizio) ) {
				
				tmp=dataInizio;
				tmpSaldo = entry.getValue().getFirst().getSaldoIniziale();
				
				giorniSaldoStabile = Duration.between(dataInizio.atStartOfDay(ZoneId.systemDefault()).toInstant(), entry.getKey().atStartOfDay(ZoneId.systemDefault()).toInstant()).toDays();
						

				logger.warn("dal  <span style='color: blue '>" + tmpDate
						+ " </span>  al   <span style='color: blue '>" + entry.getKey()
						+ "</span>\t  <span ><b>Giorni Saldo Stabile   :</b></span>   <span style='color: green '>"
						+ giorniSaldoStabile + "</span><br />");
				
				intParziali=(tmpSaldo * intGiornaliero) * (giorniSaldoStabile);
				interessi += intParziali;
				tmpDate = entry.getKey();
				
				logger.warn(
						" <span ><b>Saldo </b></span>  : <span style='color: orange '>" + tmpSaldo + "</span><br />");
				logger.warn(" <span ><b>Interessi </b></span>: <span style='color: red'>" + nf.format(intParziali)
						+ "</span><br /><br/>");

			}
			/*
			 * Controlla che il primo movimento non coincida con se stesso
			 * che nell'eventualità causerebbe una moltiplicazione per zero
			 * Nel caso non coincidesse esegue il calcolo degli interessi
			 * 
			 */
			if(entry.getKey().isAfter(dataInizio)) {
				/*
				 *Moltiplica il saldo dell'ultimo movimento effettuato per l'interesse giornaliero 
				 *e succesivamento per i giorni in cui il saldo e rimasto stabile (aka) fino al giorno del prossimo movimento
				 */
				tmpSaldo = entry.getValue().getLast().getSaldoFinale();
				giorniSaldoStabile = Duration.between(tmpDate.atStartOfDay(ZoneId.systemDefault()).toInstant(), entry.getKey().atStartOfDay(ZoneId.systemDefault()).toInstant()).toDays();

				logger.warn("dal  <span style='color: blue '>" + tmpDate
						+ " </span>  al   <span style='color: blue '>" + entry.getKey()
						+ "</span>\t  <span ><b>Giorni Saldo Stabile   :</b></span>   <span style='color: green '>"
						+ giorniSaldoStabile + "</span><br />");
				

				intParziali=(tmpSaldo * intGiornaliero) * (giorniSaldoStabile);
				interessi += intParziali;
				tmpDate = entry.getKey();
				

				logger.warn(
						" <span ><b>Saldo </b></span>  : <span style='color: orange '>" + tmpSaldo + "</span><br />");
				logger.warn(" <span ><b>Interessi </b></span> : <span style='color: red'>" + nf.format(intParziali)
						+ "</span><br /><br/>");
			}

		}
		
		if (tmpDate.isBefore(dataFine) ) {
			
			/*
			 *Nel caso non ci siano movimenti in data di fine estratto
			 *calcola i giorni di saldo stabile dall'ultimo movimento al giorno di fine estratto
			 */
			LocalDate ultimoMovimentoAnnoPrecedente=movimenti.lastKey();
			tmpSaldo = (movimenti.tailMap(dataInizio).isEmpty())? movimenti.get(ultimoMovimentoAnnoPrecedente).getLast().getSaldoFinale(): movimenti.get(tmpDate).getLast().getSaldoFinale();
			
			giorniSaldoStabile = Duration.between(tmpDate.atStartOfDay(ZoneId.systemDefault()).toInstant(), dataFine.atStartOfDay(ZoneId.systemDefault()).toInstant()).toDays();
			intParziali=(tmpSaldo * intGiornaliero) * (giorniSaldoStabile);
			interessi += intParziali;

			logger.warn(" dal  <span style='color: blue '>" + tmpDate + " </span>  al   <span style='color: blue '>"
					+ dataFine
					+ "</span>\t  <span ><b>Giorni Saldo Stabile   :</b></span>   <span style='color: green '>"
					+ giorniSaldoStabile + "</span><br />");
			logger.warn(" <span ><b>Saldo </b></span>  : <span style='color: orange '>" + tmpSaldo + "</span><br />");
			logger.warn(" <span ><b>Interessi </b></span> : <span style='color: red'>" + nf.format(intParziali)
					+ "</span><br /><br/>");
		}
		

		this.interessi(dataFine, (int) interessi);

		return interessi;
	}

}
