package contoCorrente.model;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.Duration;
import java.time.LocalDate;

import java.time.ZoneId;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.SortedMap;
import java.util.TreeMap;



public class ContoCorrente extends Conto {
	
	
	public static double tassoInteresse= 0.07;

//	--COSTR-------------------------------------------------------------------------------------------
	
	public ContoCorrente(Correntista cor) throws IllegalArgumentException {
		super(cor);
		// TODO Auto-generated constructor stub
	}
	
//	--MTD-------------------------------------------------------------------------------------------	
	
	
	@Override
	public double generaInteressi(LocalDate dataInizio, LocalDate dataFine) {

		 return generaInteressi_Padre( dataInizio,  dataFine, tassoInteresse );
	}
	
	
	

}
