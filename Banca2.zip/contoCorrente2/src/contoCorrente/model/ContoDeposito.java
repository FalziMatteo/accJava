package contoCorrente.model;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.time.Duration;
import java.time.LocalDate;

import java.time.ZoneId;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Map.Entry;


public class ContoDeposito extends Conto {
	
	public static double tassoInteresse= 0.1;

//	--COSTR-------------------------------------------------------------------------------------------
	public ContoDeposito(Correntista cor) throws IllegalArgumentException {
		super(cor);
		// TODO Auto-generated constructor stub
	}

//	--MTD-------------------------------------------------------------------------------------------
	
	@Override
	public void prelievo(LocalDate date, double importo) {
		if(importo<1001) {
			super.prelievo(date, importo);
		}else {
			super.prelievo(date, 0);
		}
	}

	
	@Override
	public double generaInteressi(LocalDate dataInizio, LocalDate dataFine) {

		 return generaInteressi_Padre( dataInizio,  dataFine, tassoInteresse );
	}

}
