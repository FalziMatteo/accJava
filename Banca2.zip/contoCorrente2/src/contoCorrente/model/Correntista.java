package contoCorrente.model;
import java.time.LocalDate;


public class Correntista {
	
	private String nome;
	private LocalDate dataDiNascita;
	

//	--COSTR-------------------------------------------------------------------------------------------

	public  Correntista(String nome, LocalDate dataDiNascita)throws  IllegalArgumentException {
		
		this.nome = nome;
		
		
		
		this.dataDiNascita = dataDiNascita;
		
	}

//	--GET-&-SET-----------------------------------------------------------------------------------------

	public String getNome() {
		return nome;
	}


	public LocalDate getDataDiNascita() {
		return dataDiNascita;
	}

//	--MTD-------------------------------------------------------------------------------------------

	@Override
	public String toString() {
		return "Correntista [nome=" + nome + ", nato il " + dataDiNascita + "]";
	}



	
	
	
	

}
