package contoCorrente.model;

import java.math.RoundingMode;
import java.text.NumberFormat;
import java.util.Locale;

public class Movimento {
	
	public static enum MOVIMENTI {
		PRELIEVO("PRELIEVO"),VERSAMENTO("VERSAMENTO"),ESTRATTO("ESTRATTO"),CHIUSURA("CHIUSURA"),INTERESSI("INTERESSI");   
		private final String value;
		MOVIMENTI(String value) {
			this.value = value; }
		};

	private MOVIMENTI tipoEnum;
	private double importo,
				saldoIniziale,
				saldoFinale;
	
	private boolean esito;
	
	public Movimento() {
		
		this.tipoEnum = null;
		this.importo = 0;
		this.saldoIniziale = 0;
		this.saldoFinale = 0;
		this.esito = false;
	}
	
	
	public Movimento(MOVIMENTI tipoEnum, double importo, double saldoIniziale) {
		
		this.tipoEnum = tipoEnum;
		this.importo = importo;
		this.saldoIniziale = saldoIniziale;
		if(tipoEnum.value=="PRELIEVO") {
			this.saldoFinale = saldoIniziale-importo;
		}else {this.saldoFinale = saldoIniziale+importo;}
		this.esito = true;
	}
	
	

	public Movimento(MOVIMENTI tipoEnum, double importo, double saldoIniziale, double saldoFinale) {
		
		this.tipoEnum = tipoEnum;
		this.importo = importo;
		this.saldoIniziale =saldoIniziale ;
		this.saldoFinale = saldoFinale;
		this.esito = false;
	}


	public String getTipoEnum() {
		return tipoEnum.value;
	}


	public double getImporto() {
		return importo;
	}


	public double getSaldoIniziale() {
		return saldoIniziale;
	}


	public double getSaldoFinale() {
		return saldoFinale;
	}


	public boolean isEsito() {
		return esito;
	}

	public static  String getEnum() {
		String stamp="";
		
		for (MOVIMENTI m:MOVIMENTI.values()) {
			if(m.value!="INTERESSI") {
							stamp+=m.value+" | ";
			}
		}
		return  stamp;
		
	}
	
	@Override
	public String toString() {
		NumberFormat nf = NumberFormat.getInstance(new Locale("it", "IT"));
		nf.setMaximumFractionDigits(2);
		nf.setRoundingMode(RoundingMode.UP);
		return String.format("| %1$-10s | %3$-14s | %2$-7s | %4$-13s | %5$-13s |", tipoEnum, nf.format(importo), nf.format(saldoIniziale),
				 nf.format(saldoFinale), esito);

	}






}

