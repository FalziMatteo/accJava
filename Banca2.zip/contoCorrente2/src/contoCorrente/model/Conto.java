package contoCorrente.model;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Locale;
import java.util.TreeMap;
import java.util.Map.Entry;
import contoCorrente.model.Movimento.MOVIMENTI;
import java.io.FileOutputStream;
import java.math.RoundingMode;
import java.text.NumberFormat;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;



import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;



public  abstract class Conto {
	
	private static String FILE = "C:/Users/Betacom/Desktop/Nuova cartella";
	private static double percentualeTassazione=0.26;
	
	protected static final Logger logger =  LogManager.getLogger(Conto.class);

	protected Correntista cor;
	protected double saldo;
	protected 	TreeMap  <LocalDate,LinkedList<Movimento>> movimenti;
	
	
	
//	--COSTR-------------------------------------------------------------------------------------------
	public   Conto(Correntista cor)throws  IllegalArgumentException {
		
			this.cor=cor;
			saldo=0;
			
			movimenti= new TreeMap  <LocalDate,LinkedList<Movimento>>();
			movimenti.put(LocalDate.parse("2021-01-01"),new LinkedList<Movimento>());
			versamento(LocalDate.parse("2021-01-01"), 1000);
			
			
			System.out.println("\n****BENVENUTO  "+cor+"****");
			System.out.print("\t\t\t");
			visualizzaSaldo	();	
		}
//	--MT-ABST-----------------------------------------------------------------------------------------
	abstract public double generaInteressi(LocalDate dataInizio,LocalDate dataFine);	
	
//	--GET-&-SET-----------------------------------------------------------------------------------------
	
	public double getSaldo() {
		return saldo ;
	}
		
	public void visualizzaSaldo() {
		

		NumberFormat nf = NumberFormat.getInstance(new Locale("it", "IT"));
		nf.setMaximumFractionDigits(2);
		nf.setRoundingMode(RoundingMode.UP);
		
		System.out.println("Il tuo saldo è:\t"+nf.format(saldo)+"\n"); 
	}
	
//	--MOVIMENTI-----------------------------------------------------------------------------------------
	
	public void prelievo(LocalDate date,double importo) {
		
		
		LinkedList<Movimento> tmp=movimenti.get(date);
		double saldoInziale=saldo;
		importo= Math.abs(importo);
		boolean result=isPrelievo(importo),
				bTmp;
				
		if(tmp==null) {
			
			tmp=new LinkedList<Movimento>();			
			bTmp=(result)?  tmp.add(new Movimento(MOVIMENTI.PRELIEVO,importo,saldoInziale)):tmp.add(new Movimento(MOVIMENTI.PRELIEVO,importo,saldoInziale,saldo));
			
			}else {
			bTmp=(result)?  tmp.add(new Movimento(MOVIMENTI.PRELIEVO,importo,saldoInziale)):tmp.add(new Movimento(MOVIMENTI.PRELIEVO,importo,saldoInziale,saldo));
			}
			
			movimenti.put(date,tmp);

	}
	
	private boolean isPrelievo (double importo) {
		boolean ret=false;
		
		if ( saldo-importo <0  ) {
	       System.out.println("Disponibilità insufficiente");
	       visualizzaSaldo();
		}else {
		ret=true;
		saldo-=importo;
		
		visualizzaSaldo();
		}
		return ret;
		
	}
	
	
	public void versamento(LocalDate date, double importo) throws IllegalArgumentException {

		LinkedList<Movimento> tmp = movimenti.get(date);
		double saldoInziale = saldo;
		
		importo= Math.abs(importo);
		saldo += importo;
		visualizzaSaldo();

		if (tmp == null) {

			tmp = new LinkedList<Movimento>();
			tmp.add(new Movimento(MOVIMENTI.VERSAMENTO, importo, saldoInziale));

		} else {
			tmp.add(new Movimento(MOVIMENTI.VERSAMENTO, importo, saldoInziale));
		}

		movimenti.put(date, tmp);

	}
	

	public void estrattoConto(LocalDate dataInizio,LocalDate dataFine) {
		/*
		 * LinkedList<Movimento> tmp=movimenti.get(dataFine);
		 * 
		 * if(tmp==null) {
		 * 
		 * tmp=new LinkedList<Movimento>(); tmp.add(new
		 * Movimento(MOVIMENTI.ESTRATTO,0,saldo));
		 * 
		 * }else {
		 * 
		 * tmp.add(new Movimento(MOVIMENTI.ESTRATTO,0,saldo)); }
		 * 
		 * movimenti.put(dataFine,tmp);
		 */
		
		NumberFormat nf = NumberFormat.getInstance(new Locale("it", "IT"));
		nf.setMaximumFractionDigits(2);
		nf.setRoundingMode(RoundingMode.UP);
		
		stampaMovimenti(dataInizio,dataFine);
		System.out.println("\nSALDO FINALE: "+ nf.format(saldo)+String.format("\n%100s"," ").replace(" " , "-"));

	}
	
	private void stampaMovimenti(LocalDate dataInizio,LocalDate dataFine) {

		System.out.println(String.format("\n%100s"," ").replace(" " , "-")
				+String.format("\n| %1$-21s | %2$-24s | %3$-15s|  ","ESTRATTO CONTO ", "CORRENTISTA :"+ cor.getNome(), "DATA "+LocalDate.now() )
				+String.format("\n%100s"," ").replace(" " , "- ")
				+String.format("\n| %6$-10s  | %1$-10s | %3$-14s| %2$-8s | %4$-13s | %5$-13s |", "OPERAZIONE",  "IMPORTO","SALDO INIZIALE","SALDO FINALE","ESITO","DATA"));

		for (Entry <LocalDate,LinkedList<Movimento>> entry : movimenti.tailMap(dataInizio).entrySet()) { 
			if(entry.getKey().isBefore(dataFine) |entry.getKey().equals(dataFine) ) {
				for(Movimento mov : entry.getValue()) {
				
						System.out.println("| "+entry.getKey()+"| "+mov);
				}
			}
		}
	}
		
	
	public void interessi (LocalDate date,double importo) throws  IllegalArgumentException{
		
		LinkedList<Movimento> tmp=movimenti.get(date);
		
		double saldoInziale=saldo;
		
		double intNetti=importo-(importo*percentualeTassazione);
		
		saldo+=intNetti;


		if(tmp==null) {
			
			tmp=new LinkedList<Movimento>();			
			tmp.add(new Movimento(MOVIMENTI.INTERESSI,intNetti,saldoInziale));
			
			}else {
			 tmp.add(new Movimento(MOVIMENTI.INTERESSI,intNetti,saldoInziale));
			}
			
			movimenti.put(date,tmp);
				
	
	}
	
		
//	--PDF-----------------------------------------------------------------------------------------

	public void writePDF(LocalDate dataInizio, LocalDate dataFine, String finePath) {

		Document document = new Document();

		Font 	titolo = new Font(Font.FontFamily.TIMES_ROMAN, 14, Font.BOLD),
				rosso = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL, BaseColor.RED),
				normale = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.NORMAL);

		try {
			PdfWriter.getInstance(document, new FileOutputStream(FILE + "/" + finePath));
			document.open();


			document.add(addTitolo(titolo, normale, dataInizio, dataFine));
			document.add(addTable(rosso, normale, dataInizio, dataFine));
			document.add(addFine(rosso, normale, dataFine));

			document.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private Paragraph addTitolo(Font fTitolo, Font normale, LocalDate dataInizio, LocalDate dataFine) {

		Paragraph p, preface = new Paragraph();

		preface.setAlignment(Element.ALIGN_CENTER);

//		Titolo
		addEmptyLine(preface, 1);
		p = new Paragraph("ESTRATTO " + (this.getClass().getSimpleName().replace("Conto", "Conto ")).toUpperCase()
				+ "  " + dataInizio.getYear(), fTitolo);
		p.setAlignment(Element.ALIGN_CENTER);
		preface.add(p);

//		Nome Utente
		addEmptyLine(preface, 1);
		preface.add(new Paragraph(String.format("%100s", " ").replace(" ", "-"), normale));
		preface.add(
				new Paragraph("Correntista: \t " + cor.getNome().toUpperCase() + ",  in data:\t" + dataFine, normale));
		preface.add(new Paragraph(String.format("%100s", " ").replace(" ", "-"), normale));
		addEmptyLine(preface, 1);

		return preface;

	}

	private Paragraph addTable(Font rosso, Font normale, LocalDate dataInizio, LocalDate dataFine)
			throws DocumentException {

	

		Paragraph content = new Paragraph();
		PdfPTable table = new PdfPTable(6);
		NumberFormat nf = NumberFormat.getInstance(new Locale("it", "IT"));

		nf.setMaximumFractionDigits(2);
		nf.setRoundingMode(RoundingMode.UP);

		table.addCell(headerCell("OPERAZIONE", rosso));
		table.addCell(headerCell("DATA", rosso));
		table.addCell(headerCell("IMPORTO", rosso));
		table.addCell(headerCell("SALDO INIZIALE", rosso));
		table.addCell(headerCell("SALDO FINALE", rosso));
		table.addCell(headerCell("ESITO", rosso));

		int i = 0;
		for (Entry<LocalDate, LinkedList<Movimento>> entry : movimenti.tailMap(dataInizio).entrySet()) {
			if (entry.getKey().isBefore(dataFine) | entry.getKey().equals(dataFine)) {
				for (Movimento m : entry.getValue()) {

					table.addCell(tableCell("" + m.getTipoEnum().toLowerCase(), normale, i));
					table.addCell(tableCell("" + entry.getKey(), normale, i));
					table.addCell(tableCell("" + nf.format(m.getImporto()), normale, i));
					table.addCell(tableCell("" + nf.format(m.getSaldoIniziale()), normale, i));
					table.addCell(tableCell("" + nf.format(m.getSaldoFinale()), normale, i));
					table.addCell(tableCell("" + m.isEsito(), normale, i));

					i++;

//		for		
				}
			}
		}
		content.add(table);
		return content;

	}

	private PdfPCell headerCell(String campo, Font font) {

		Phrase p = new Phrase(campo.toUpperCase());
		p.setFont(font);

		PdfPCell cell = new PdfPCell(p);
		cell.setBackgroundColor(BaseColor.YELLOW);

		return cell;
	}

	private PdfPCell tableCell(String campo, Font font, int i) {

		Phrase p = new Phrase(campo.toUpperCase());
		p.setFont(font);

		PdfPCell cell = new PdfPCell(p);

		if (i % 2 != 0)
			cell.setBackgroundColor(BaseColor.LIGHT_GRAY);

		return cell;
	}

	private Paragraph addFine(Font rosso, Font normale, LocalDate dataFine) {

		Paragraph preface = new Paragraph();
		NumberFormat nf = NumberFormat.getInstance(new Locale("it", "IT"));
		Iterator<Movimento> iterator = movimenti.get(dataFine).descendingIterator();
		boolean trovato = false;
		double interessi = 0;


		nf.setMaximumFractionDigits(2);
		nf.setRoundingMode(RoundingMode.UP);

		preface.setAlignment(Element.ALIGN_CENTER);
		preface.add(new Paragraph(String.format("%100s", " ").replace(" ", "-"), normale));
		preface.add(new Paragraph("Saldo finale: \t " + nf.format(saldo), normale));

		while (!trovato) {
			Movimento m = iterator.next();
			if (m.getTipoEnum().equalsIgnoreCase("INTERESSI")) {
				interessi = m.getImporto();
				trovato = true;
			}
		}

		preface.add(new Paragraph("\nInteressi maturati al 31/12 lordi: \t " + nf.format(interessi/(1-percentualeTassazione)), normale));
		preface.add(new Paragraph("\nInteressi maturati al 31/12 netti: \t " + nf.format(interessi), normale));
		preface.add(new Paragraph(String.format("%100s", " ").replace(" ", "-"), normale));

		return preface;

	}

	private void addEmptyLine(Paragraph paragraph, int number) {
		for (int i = 0; i < number; i++) {
			paragraph.add(new Paragraph(" "));
		}
	}

	


	
	
	
	
}






